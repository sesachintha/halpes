const featureOne = [
  {
    id: 1,
    title: "Become a Volunteer",
    icon: "icon-heart",
    description: "Lorem ium dolor sit ametad pisicing elit sed do ut.",
  },
  {
    id: 2,
    title: "Quick Fundrais",
    icon: "icon-adoption",
    description: "Lorem ium dolor sit ametad pisicing elit sed do ut.",
  },
  {
    id: 3,
    title: "Donate Now",
    icon: "icon-donation-1",
    description: "Lorem ium dolor sit ametad pisicing elit sed do ut.",
  },
];

export default featureOne;
