const testimonialTwo = [
  {
    id: 1,
    description:
      "Lorem ipsum is simply free text dolor sit amet, consectetur notted adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    image: "testimonial-2-img-1.png",
    name: "Kevin Martin",
    category: "Volunteer",
  },
  {
    id: 2,
    description:
      "Lorem ipsum is simply free text dolor sit amet, consectetur notted adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    image: "testimonial-2-img-2.png",
    name: "Jessica Brown",
    category: "Volunteer",
  },
  {
    id: 3,
    description:
      "Lorem ipsum is simply free text dolor sit amet, consectetur notted adipisicing elit sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.",
    image: "testimonial-2-img-3.png",
    name: "Jessica Brown",
    category: "Volunteer",
  },
];

export default testimonialTwo;
