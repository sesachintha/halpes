const helpThem = [
  {
    id: 1,
    icon: "icon-charity",
    title: "Become a Volunteer",
    subTitle:
      "There are many variations of but the majority have simply free text suffered.",
  },
  {
    id: 2,
    icon: "icon-generous",
    title: "Quick Fundraising",
    subTitle:
      "There are many variations of but the majority have simply free text suffered.",
  },
  {
    id: 3,
    icon: "icon-fundraiser",
    title: "Start Donating",
    subTitle:
      "There are many variations of but the majority have simply free text suffered.",
  },
];

export default helpThem;
