const newsTwo = [
  {
    id: 1,
    image: "news-two-img-1.jpg",
    date: "20 Jan, 2021",
    title: "Donation is Hope for Poor Childrens in",
    description:
      "There are many variations of but the majority have simply free text available not suffered.",
    author: "Admin",
    comments: 2,
  },
  {
    id: 2,
    image: "news-two-img-2.jpg",
    date: "20 Jan, 2021",
    title: "How Malnutrition Affect Children?",
    description:
      "There are many variations of but the majority have simply free text available not suffered.",
    author: "Admin",
    comments: 2,
  },
  {
    id: 3,
    image: "news-two-img-3.jpg",
    date: "20 Jan, 2021",
    title: "Capitalize on low hanging to identify",
    description:
      "There are many variations of but the majority have simply free text available not suffered.",
    author: "Admin",
    comments: 2,
  },
];

export default newsTwo;
