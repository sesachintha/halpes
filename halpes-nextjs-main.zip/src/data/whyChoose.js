const whyChoose = {
  tagline: "Get Daily Updates",
  title: "Why you should choose our \n charity foundation",
  description:
    "There are many variations of passages of but the majority have suffered alteration in some form by injected humour or which don't look even slightly believe.",
  signature: "Mike Hardson",
  listIcon: "fa-arrow-circle-right",
  urgentTitle: "Raise Fund for Save Animals",
  urgentDescription:
    "Lorem ipsum dolor sit amet, consectetur adipisicing elit sed do eiusmod tempor incididunt.",
  raised: "25,270",
  goal: "30,000",
  category: "Medical",
  list: [
    "Making this first true generator",
    "Many desktop publish packages",
    "Lorem Ipsum is not simply",
    "If you are going to passage",
    "It has roots in a piece",
    "The point of using",
  ],
};

export default whyChoose;
