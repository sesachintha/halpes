const introduction = [
  {
    id: 1,
    icon: "icon-college-graduation",
    title: "Childrens Education",
    description:
      "Lorem ipsum dolor sit amet, consectetur elit, sed do eiusmod tempor anagi icdunt ut.",
  },
  {
    id: 2,
    icon: "icon-coin",
    title: "Support Them",
    description:
      "Lorem ipsum dolor sit amet, consectetur elit, sed do eiusmod tempor anagi icdunt ut.",
  },
];

export default introduction;
