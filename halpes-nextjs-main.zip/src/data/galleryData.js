const galleryData = [
  {
    id: 1,
    image: "gallery-1-1.jpg",
    title: "Child Education",
    subTitle: "Charity",
  },
  {
    id: 2,
    image: "gallery-1-2.jpg",
    title: "Child Education",
    subTitle: "Charity",
  },
  {
    id: 3,
    image: "gallery-1-3.jpg",
    title: "Child Education",
    subTitle: "Charity",
  },
  {
    id: 4,
    image: "gallery-1-4.jpg",
    title: "Child Education",
    subTitle: "Charity",
  },
  {
    id: 5,
    image: "gallery-1-5.jpg",
    title: "Child Education",
    subTitle: "Charity",
  },
  {
    id: 6,
    image: "gallery-1-3.jpg",
    title: "Child Education",
    subTitle: "Charity",
  },
];

export default galleryData;
