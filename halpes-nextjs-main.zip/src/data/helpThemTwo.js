import background from "@/images/resources/help-them-two-bg.jpg";
import image from "@/images/resources/help-them-two-img-1.jpg";
import image2 from "@/images/resources/help-them-two__donation-icon.png";

const helpThemTwo = {
  image,
  image2,
  background,
  videoId: "i9E_Blai8vk",
  tagline: "We Help Them",
  title: "Trusted non profit \n donation center",
  bottomTitle: "Halpes is the largest global crowdfunding.",
  bottomDescription:
    "Lorem ipsum dolor sit am adipi we help you ensure everyone is in the right jobs sicing elit, sed do consulting firms Et leggings across the nation simply free text tempor.",
  list: [
    "Best fundraising platform",
    "We can help to educate them",
    "Best fundraising platform",
    "We can help to educate them",
  ],
};

export default helpThemTwo;
