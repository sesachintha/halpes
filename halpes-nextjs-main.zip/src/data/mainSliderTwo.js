import bg3 from "@/images/backgrounds/main-slider-1-1.jpg";
import bg1 from "@/images/backgrounds/main-slider-2-1.jpg";
import bg2 from "@/images/backgrounds/main-slider-2-2.jpg";

const mainSliderTwo = [
  {
    id: 1,
    bg: bg1,
    subTitle: "Help is Our Goal",
    title: "Give them a",
    href: "#",
  },
  {
    id: 2,
    bg: bg2,
    subTitle: "Help is Our Goal",
    title: "Give them a",
    href: "#",
  },
  {
    id: 3,
    bg: bg3,
    subTitle: "Help is Our Goal",
    title: "Give them a",
    href: "#",
  },
];

export default mainSliderTwo;
