const aboutProgress = [
  {
    id: 1,
    percentage: 90,
    title: "Successful causes",
  },
  {
    id: 2,
    percentage: 50,
    title: "Amazing donors",
  },
];

export default aboutProgress;
