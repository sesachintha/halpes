const events = [
  {
    id: 1,
    image: "events-one-img-1.jpg",
    date: "20 Jan",
    time: "8:00 pm",
    title: "Play for the \n world with us",
  },
  {
    id: 2,
    image: "events-one-img-2.jpg",
    date: "20 Jan",
    time: "8:00 pm",
    title: "Mission for Fresh \n & Clean Water",
  },
  {
    id: 3,
    image: "events-one-img-3.jpg",
    date: "20 Jan",
    time: "8:00 pm",
    title: "Education for \n poor children",
  },
  {
    id: 4,
    image: "events-one-img-1.jpg",
    date: "20 Jan",
    time: "8:00 pm",
    title: "Play for the \n world with us",
  },
  {
    id: 5,
    image: "events-one-img-2.jpg",
    date: "20 Jan",
    time: "8:00 pm",
    title: "Mission for Fresh \n & Clean Water",
  },
  {
    id: 6,
    image: "events-one-img-3.jpg",
    date: "20 Jan",
    time: "8:00 pm",
    title: "Education for \n poor children",
  },
];

export default events;
