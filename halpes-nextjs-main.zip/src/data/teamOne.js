const teamOne = [
  {
    id: 1,
    image: "team-one-img-1.jpg",
    name: "Janne",
    title: "Volunteer",
    description:
      "There are many of lorem ipsum available but the have in some form.",
  },
  {
    id: 2,
    image: "team-one-img-2.jpg",
    name: "David",
    title: "Volunteer",
    description:
      "There are many of lorem ipsum available but the have in some form.",
  },
  {
    id: 3,
    image: "team-one-img-3.jpg",
    name: "Sarah",
    title: "Volunteer",
    description:
      "There are many of lorem ipsum available but the have in some form.",
  },
  {
    id: 4,
    image: "team-page-img-4.jpg",
    name: "Albert",
    title: "Volunteer",
    description:
      "There are many of lorem ipsum available but the have in some form.",
  },
  {
    id: 5,
    image: "team-page-img-5.jpg",
    name: "Hallen",
    title: "Volunteer",
    description:
      "There are many of lorem ipsum available but the have in some form.",
  },
  {
    id: 6,
    image: "team-page-img-6.jpg",
    name: "Pitter",
    title: "Volunteer",
    description:
      "There are many of lorem ipsum available but the have in some form.",
  },
];

export default teamOne;
