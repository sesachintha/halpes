const causesThree = [
  {
    id: 1,
    image: "causes-three-img-1.jpg",
    category: "Medical",
    title: "Raise Fund for Clean & Healthy Water",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
  {
    id: 2,
    image: "causes-three-img-2.jpg",
    category: "Medical",
    title: "School Counseling for Children",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
  {
    id: 3,
    image: "causes-three-img-3.jpg",
    category: "Medical",
    title: "Fundrising for Early Childhood Rise",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
  {
    id: 4,
    image: "causes-three-img-4.jpg",
    category: "Medical",
    title: "Promoting The Rights of Children",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
  {
    id: 5,
    image: "causes-three-img-1.jpg",
    category: "Medical",
    title: "Education for Poor Children",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
  {
    id: 6,
    image: "causes-three-img-2.jpg",
    category: "Medical",
    title: "Raise Fund for Clean & Healthy Water",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
  {
    id: 7,
    image: "causes-three-img-3.jpg",
    category: "Medical",
    title: "Raise Fund for Clean & Healthy Water",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
  {
    id: 8,
    image: "causes-three-img-4.jpg",
    category: "Medical",
    title: "Raise Fund for Clean & Healthy Water",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
  {
    id: 9,
    image: "causes-three-img-1.jpg",
    category: "Medical",
    title: "Raise Fund for Clean & Healthy Water",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
];

export default causesThree;
