const threeBoxes = [
  {
    id: 1,
    icon: "icon-fast-food",
    className: "",
    title: "Healthy Food",
  },
  {
    id: 2,
    icon: "icon-water",
    className: "three-boxes__single-item-two",
    title: "Clean Water",
  },
  {
    id: 3,
    icon: "icon-health-check",
    className: "three-boxes__single-item-three",
    title: "Medical Treatment",
  },
];

export default threeBoxes;
