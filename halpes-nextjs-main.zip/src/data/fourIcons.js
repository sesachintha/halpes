const fourIcons = [
  {
    id: 1,
    image: "four-icon-img-1.jpg",
    title: "We Help",
    description:
      "There are many lipsum of pass of but the have in that not some.",
    icon: "icon-dove",
  },
  {
    id: 2,
    image: "four-icon-img-2.jpg",
    title: "We Educate",
    description:
      "There are many lipsum of pass of but the have in that not some.",
    icon: "icon-cheque",
  },
  {
    id: 3,
    image: "four-icon-img-3.jpg",
    title: "We Build",
    description:
      "There are many lipsum of pass of but the have in that not some.",
    icon: "icon-donation",
  },
  {
    id: 4,
    image: "four-icon-img-4.jpg",
    title: "We Nourish",
    description:
      "There are many lipsum of pass of but the have in that not some.",
    icon: "icon-handshake",
  },
];

export default fourIcons;
