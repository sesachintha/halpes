const becomeVolunteerList = [
  "Making this first true generator simply text",
  "Many desktop publish packages nothing",
  "Lorem Ipsum is not simply free text",
  "If you are going to passage",
  "It has roots in a piece",
];

export default becomeVolunteerList;
