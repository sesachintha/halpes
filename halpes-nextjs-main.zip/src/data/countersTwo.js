const countersTwo = [
  {
    id: 1,
    icon: "icon-fast-food",
    title: "Healthy Food",
  },
  {
    id: 2,
    icon: "icon-water",
    title: "Clean Water",
  },
  {
    id: 3,
    icon: "icon-health-check",
    title: "Medical Treatment",
  },
  {
    id: 4,
    icon: "icon-cheque",
    title: "Child Education",
  },
];

export default countersTwo;
