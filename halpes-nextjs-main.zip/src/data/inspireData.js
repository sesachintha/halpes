const inspireData = [
  {
    id: 1,
    question: "We help to create better lives",
    answer:
      "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
  },
  {
    id: 2,
    question: "We help to create better lives",
    answer:
      "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
  },
  {
    id: 3,
    question: "We help to create better lives",
    answer:
      "There are many variations of passages the majority have suffered alteration in some fo injected humour, or randomised words believable.",
  },
];

export default inspireData;
