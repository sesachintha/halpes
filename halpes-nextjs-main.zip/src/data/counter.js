const counter = [
  {
    id: 1,
    count: 870,
    letter: "K",
    text: "Total Donations",
  },
  {
    id: 2,
    count: 480,
    text: "Campaigns Closed",
  },
  {
    id: 3,
    count: 977,
    letter: "K",
    text: "Happy People",
  },
  {
    id: 4,
    count: 63,
    letter: "+",
    text: "Our Volunteers",
  },
];

export default counter;
