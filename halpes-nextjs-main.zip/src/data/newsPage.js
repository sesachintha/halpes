const newsPage = [
  {
    id: 1,
    image: "news-page-img-1.jpg",
    date: "20 Jan, 2021",
    title: "Donation is Hope for Poor Childrens in",
    description:
      "There are many variations of but the majority have simply free text available not suffered.",
    author: "Admin",
    comments: 2,
  },
  {
    id: 2,
    image: "news-page-img-2.jpg",
    date: "20 Jan, 2021",
    title: "How Malnutrition Affect Children?",
    description:
      "There are many variations of but the majority have simply free text available not suffered.",
    author: "Admin",
    comments: 2,
  },
  {
    id: 3,
    image: "news-page-img-3.jpg",
    date: "20 Jan, 2021",
    title: "Capitalize on low hanging to identify",
    description:
      "There are many variations of but the majority have simply free text available not suffered.",
    author: "Admin",
    comments: 2,
  },
  {
    id: 4,
    image: "news-page-img-4.jpg",
    date: "20 Jan, 2021",
    title: "Override the digital divide with additional",
    description:
      "There are many variations of but the majority have simply free text available not suffered.",
    author: "Admin",
    comments: 2,
  },
  {
    id: 5,
    image: "news-page-img-5.jpg",
    date: "20 Jan, 2021",
    title: "Nanotechnology immersion along the",
    description:
      "There are many variations of but the majority have simply free text available not suffered.",
    author: "Admin",
    comments: 2,
  },
  {
    id: 6,
    image: "news-page-img-6.jpg",
    date: "20 Jan, 2021",
    title: "User generate in have multi time",
    description:
      "There are many variations of but the majority have simply free text available not suffered.",
    author: "Admin",
    comments: 2,
  },
];

export default newsPage;
