const causesPageData = [
  {
    id: 1,
    image: "causes-page-img-1.jpg",
    category: "Medical",
    title: "Raise Fund for Clean & Healthy Water",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
  {
    id: 2,
    image: "causes-page-img-2.jpg",
    category: "Medical",
    title: "Our donation is hope for poor childrens",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
  {
    id: 3,
    image: "causes-page-img-3.jpg",
    category: "Medical",
    title: "Education for Poor Children",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
  {
    id: 4,
    image: "causes-page-img-4.jpg",
    category: "Medical",
    title: "Promoting The Rights of Children",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
  {
    id: 5,
    image: "causes-page-img-5.jpg",
    category: "Medical",
    title: "Fundrising for Early Childhood Rise",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
  {
    id: 6,
    image: "causes-page-img-6.jpg",
    category: "Medical",
    title: "School Counseling for Children",
    description:
      "There are not many of passages of lorem ipsum avail isn alteration donationa in form simply free.",
    raised: "25,270",
    goal: "30,000",
  },
];

export default causesPageData;
