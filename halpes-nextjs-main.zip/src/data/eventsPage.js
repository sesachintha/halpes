const eventsPage = [
  {
    id: 1,
    image: "events-page-img-1.jpg",
    date: "20 Jan",
    time: "8:00 pm",
    title: "Play for the \n world with us",
  },
  {
    id: 2,
    image: "events-page-img-2.jpg",
    date: "20 Jan",
    time: "8:00 pm",
    title: "Mission for Fresh \n & Clean Water",
  },
  {
    id: 3,
    image: "events-page-img-3.jpg",
    date: "20 Jan",
    time: "8:00 pm",
    title: "Education for \n poor children",
  },
  {
    id: 4,
    image: "events-page-img-4.jpg",
    date: "20 Jan",
    time: "8:00 pm",
    title: "Rights for \n street childrens",
  },
  {
    id: 5,
    image: "events-page-img-5.jpg",
    date: "20 Jan",
    time: "8:00 pm",
    title: "Help for \n needy people",
  },
  {
    id: 6,
    image: "events-page-img-6.jpg",
    date: "20 Jan",
    time: "8:00 pm",
    title: "Donation day \n for people",
  },
];

export default eventsPage;
