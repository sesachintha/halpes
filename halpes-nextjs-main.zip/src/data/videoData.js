const VideoData = {
  title: "Watch the Video",
  id: "i9E_Blai8vk",
};

export default VideoData;
