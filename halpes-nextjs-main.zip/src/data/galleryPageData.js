const galleryPageData = [
  {
    id: 1,
    image: "gallery-page-img-1.jpg",
    title: "Child Education",
    category: "Charity",
  },
  {
    id: 2,
    image: "gallery-page-img-2.jpg",
    title: "Child Education",
    category: "Charity",
  },
  {
    id: 3,
    image: "gallery-page-img-3.jpg",
    title: "Child Education",
    category: "Charity",
  },
  {
    id: 4,
    image: "gallery-page-img-4.jpg",
    title: "Child Education",
    category: "Charity",
  },
  {
    id: 5,
    image: "gallery-page-img-5.jpg",
    title: "Child Education",
    category: "Charity",
  },
  {
    id: 6,
    image: "gallery-page-img-6.jpg",
    title: "Child Education",
    category: "Charity",
  },
  {
    id: 7,
    image: "gallery-page-img-7.jpg",
    title: "Child Education",
    category: "Charity",
  },
  {
    id: 8,
    image: "gallery-page-img-8.jpg",
    title: "Child Education",
    category: "Charity",
  },
  {
    id: 9,
    image: "gallery-page-img-9.jpg",
    title: "Child Education",
    category: "Charity",
  },
];

export default galleryPageData;
