const mainSliderThree = [
  {
    id: 1,
    image: "main-slider-3-shape-1.png",
    bg: "main-slider-3-1.jpg",
    subTitle: "Helping Them Today",
    title: "Help the Poor \n in Need",
    href: "#",
  },
  {
    id: 2,
    image: "main-slider-3-shape-1.png",
    bg: "main-slider-3-2.png",
    subTitle: "Helping Them Today",
    title: "Help the Poor \n in Need",
    href: "#",
  },
];

export default mainSliderThree;
