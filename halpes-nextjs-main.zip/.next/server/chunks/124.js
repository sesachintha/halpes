"use strict";
exports.id = 124;
exports.ids = [124];
exports.modules = {

/***/ 3430:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/footer-bg.a97d3ee0.jpg","height":590,"width":1920,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAACAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAf/xAAcEAABAwUAAAAAAAAAAAAAAAAAAhESExQhMVL/xAAUAQEAAAAAAAAAAAAAAAAAAAAA/8QAFBEBAAAAAAAAAAAAAAAAAAAAAP/aAAwDAQACEQMRAD8ApNNFzOCZdNnQAA//2Q=="});

/***/ }),

/***/ 575:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/contact-page-img-1.aa65b11d.jpg","height":186,"width":510,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAADAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAf/xAAbEAABBAMAAAAAAAAAAAAAAAAAARESEwJRsf/EABQBAQAAAAAAAAAAAAAAAAAAAAD/xAAUEQEAAAAAAAAAAAAAAAAAAAAA/9oADAMBAAIRAxEAPwCnU4StZZ7deAAD/9k="});

/***/ }),

/***/ 948:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/footer-logo.ca0ed00f.jpg","height":138,"width":260,"blurDataURL":"data:image/jpeg;base64,/9j/2wBDAAoHBwgHBgoICAgLCgoLDhgQDg0NDh0VFhEYIx8lJCIfIiEmKzcvJik0KSEiMEExNDk7Pj4+JS5ESUM8SDc9Pjv/2wBDAQoLCw4NDhwQEBw7KCIoOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozv/wAARCAAEAAgDASIAAhEBAxEB/8QAFQABAQAAAAAAAAAAAAAAAAAAAAT/xAAaEAACAgMAAAAAAAAAAAAAAAAAEgECEUFC/8QAFQEBAQAAAAAAAAAAAAAAAAAABAf/xAAWEQEBAQAAAAAAAAAAAAAAAAAAAkH/2gAMAwEAAhEDEQA/ALXhFSuY62ABCeVj/9k="});

/***/ }),

/***/ 1159:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = ({"src":"/_next/static/media/logo-1.6da06727.png","height":51,"width":121,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAgAAAADCAMAAACZFr56AAAAIVBMVEX///////////////9MaXH////////////////////////reVcBAAAAC3RSTlONMT1+AGxWAWQXqVl2/U8AAAAJcEhZcwAACxMAAAsTAQCanBgAAAAiSURBVHicBcGBAQAgCMOwsg1Q/z/YhNbNJuH0aEpFGT/wBwWsAFttcbtcAAAAAElFTkSuQmCC"});

/***/ }),

/***/ 8124:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Z": () => (/* binding */ Layout_Layout)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: ./node_modules/next/dynamic.js
var dynamic = __webpack_require__(5152);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./src/components/Header/Header.js



const HeaderOne = (0,dynamic["default"])(()=>Promise.all(/* import() */[__webpack_require__.e(476), __webpack_require__.e(418)]).then(__webpack_require__.bind(__webpack_require__, 2418))
, {
    loadableGenerated: {
        modules: [
            "..\\components\\Header\\Header.js -> " + "./HeaderOne"
        ]
    }
});
const HeaderTwo = (0,dynamic["default"])(()=>Promise.all(/* import() */[__webpack_require__.e(476), __webpack_require__.e(642)]).then(__webpack_require__.bind(__webpack_require__, 7642))
, {
    loadableGenerated: {
        modules: [
            "..\\components\\Header\\Header.js -> " + "./HeaderTwo"
        ]
    }
});
const HeaderThree = (0,dynamic["default"])(()=>Promise.all(/* import() */[__webpack_require__.e(476), __webpack_require__.e(714)]).then(__webpack_require__.bind(__webpack_require__, 1714))
, {
    loadableGenerated: {
        modules: [
            "..\\components\\Header\\Header.js -> " + "./HeaderThree"
        ]
    }
});
const Header = ({ pageTitle  })=>{
    return pageTitle === "Home Two" ? /*#__PURE__*/ jsx_runtime_.jsx(HeaderTwo, {}) : pageTitle === "Home Three" ? /*#__PURE__*/ jsx_runtime_.jsx(HeaderThree, {}) : /*#__PURE__*/ jsx_runtime_.jsx(HeaderOne, {});
};
/* harmony default export */ const Header_Header = (Header);

;// CONCATENATED MODULE: ./src/assets/images/loader.png
/* harmony default export */ const loader = ({"src":"/_next/static/media/loader.2fa8239b.png","height":80,"width":60,"blurDataURL":"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAYAAAAICAMAAADtGH4KAAAAJFBMVEVMaXERxqEUyKAUyqEUyqIUyZ8TxZwUyJ8TyKAP0rQTyp8SyJ1gm7SuAAAADHRSTlMAHWWZsEcsyHcIP1T5eSdwAAAACXBIWXMAAAsTAAALEwEAmpwYAAAAL0lEQVR4nBXFxxHAQAwDsaVI6VL//XqMD2gbDT6+HUK2NpFVg4tu0HoDUOv+oRQfE88Aoan2rM4AAAAASUVORK5CYII="});
// EXTERNAL MODULE: external "react-bootstrap"
var external_react_bootstrap_ = __webpack_require__(358);
;// CONCATENATED MODULE: ./src/components/Preloader.js




const Preloader = ({ loading  })=>{
    return(/*#__PURE__*/ jsx_runtime_.jsx("div", {
        style: {
            opacity: loading ? 1 : 0,
            transition: "1s ease",
            zIndex: 0
        },
        className: "preloader",
        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Image, {
            className: "preloader__image",
            width: "60",
            src: loader.src,
            alt: ""
        })
    }));
};
/* harmony default export */ const components_Preloader = (Preloader);

// EXTERNAL MODULE: ./src/context/context.js
var context = __webpack_require__(9343);
// EXTERNAL MODULE: ./src/hooks/useScroll.js
var useScroll = __webpack_require__(292);
// EXTERNAL MODULE: external "next/head"
var head_ = __webpack_require__(968);
var head_default = /*#__PURE__*/__webpack_require__.n(head_);
// EXTERNAL MODULE: external "react-scroll"
var external_react_scroll_ = __webpack_require__(3094);
// EXTERNAL MODULE: ./src/data/NavItems.js
var NavItems = __webpack_require__(4181);
// EXTERNAL MODULE: ./src/assets/images/resources/logo-1.png
var logo_1 = __webpack_require__(1159);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./src/components/MobileMenu/SubNavItem.js



const SubNavItem = ({ subItem ={}  })=>{
    const { 0: expand , 1: setExpand  } = (0,external_react_.useState)(false);
    const handleExpand = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setExpand((preExpand)=>!preExpand
        );
    };
    const { href , subItems , name  } = subItem;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                href: href,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    className: expand && (subItems === null || subItems === void 0 ? void 0 : subItems.length) ? " expanded" : "",
                    children: [
                        name,
                        (subItems === null || subItems === void 0 ? void 0 : subItems.length) && /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: handleExpand,
                            ariaLabel: "dropdown toggler",
                            className: expand ? "expanded" : "",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "fa fa-angle-down"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                style: {
                    display: expand ? "block" : "none"
                },
                children: subItems === null || subItems === void 0 ? void 0 : subItems.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: item.href,
                            children: item.name
                        })
                    }, item.id)
                )
            })
        ]
    }));
};
/* harmony default export */ const MobileMenu_SubNavItem = (SubNavItem);

;// CONCATENATED MODULE: ./src/components/MobileMenu/NavItem.js






const NavItem = ({ item ={}  })=>{
    const { pathname  } = (0,router_.useRouter)();
    const { 0: expand , 1: setExpand  } = (0,external_react_.useState)(false);
    const handleExpand = (e)=>{
        e.preventDefault();
        e.stopPropagation();
        setExpand((preExpand)=>!preExpand
        );
    };
    const { name , href , subNavItems  } = item;
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
        className: `dropdown${pathname === href ? " current" : ""}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                href: href,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                    className: expand ? " expanded" : "",
                    children: [
                        name,
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            onClick: handleExpand,
                            ariaLabel: "dropdown toggler",
                            className: expand ? "expanded" : "",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "fa fa-angle-down"
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                style: {
                    display: expand ? "block" : "none"
                },
                children: subNavItems.map((subItem)=>/*#__PURE__*/ jsx_runtime_.jsx(MobileMenu_SubNavItem, {
                        subItem: subItem
                    }, subItem.id)
                )
            })
        ]
    }));
};
/* harmony default export */ const MobileMenu_NavItem = (NavItem);

;// CONCATENATED MODULE: ./src/components/MobileMenu/MobileMenu.js








const MobileMenu = ()=>{
    const { toggleMenu , menuStatus  } = (0,context/* useRootContext */.E)();
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `mobile-nav__wrapper  animated fadeInLeft${menuStatus ? " expanded" : ""}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                onClick: ()=>toggleMenu()
                ,
                className: "mobile-nav__overlay mobile-nav__toggler"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: "mobile-nav__content",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        onClick: ()=>toggleMenu()
                        ,
                        className: "mobile-nav__close mobile-nav__toggler",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                            className: "fa fa-times"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "logo-box",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                            href: "/",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                "aria-label": "logo image",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Image, {
                                    src: logo_1["default"].src,
                                    width: "155",
                                    alt: ""
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mobile-nav__container",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                            className: "main-menu__list",
                            children: NavItems/* default.map */.Z.map(({ id , ...item })=>/*#__PURE__*/ jsx_runtime_.jsx(MobileMenu_NavItem, {
                                    item: item
                                }, id)
                            )
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                        className: "mobile-nav__contact list-unstyled",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fa fa-envelope"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "mailto:needhelp@packageName__.com",
                                        children: "needhelp@halpes.com"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                        className: "fa fa-phone-alt"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                        href: "tel:666-888-0000",
                                        children: "666 888 0000"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "mobile-nav__top",
                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            className: "mobile-nav__social",
                            children: NavItems/* social.map */.x.map(({ icon , link  }, index)=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                                    href: link,
                                    className: `fab ${icon}`
                                }, index)
                            )
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const MobileMenu_MobileMenu = (MobileMenu);

;// CONCATENATED MODULE: ./src/components/Search/Search.js



const Search = ()=>{
    const { openSearch , toggleSearch  } = (0,context/* useRootContext */.E)();
    const handleSearch = (e)=>{
        e.preventDefault();
        const formData = new FormData(e.target);
        console.log(formData.get("search"));
    };
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: `search-popup${openSearch ? " active" : ""}`,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                onClick: toggleSearch,
                className: "search-popup__overlay search-toggler"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "search-popup__content",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                    onSubmit: handleSearch,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx("label", {
                            htmlFor: "search",
                            className: "sr-only",
                            children: "search here"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("input", {
                            type: "text",
                            name: "search",
                            id: "search",
                            placeholder: "Search Here..."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("button", {
                            type: "submit",
                            "aria-label": "search submit",
                            className: "thm-btn",
                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                className: "icon-magnifying-glass"
                            })
                        })
                    ]
                })
            })
        ]
    }));
};
/* harmony default export */ const Search_Search = (Search);

// EXTERNAL MODULE: ./src/assets/images/backgrounds/footer-bg.jpg
var footer_bg = __webpack_require__(3430);
// EXTERNAL MODULE: ./src/assets/images/resources/footer-logo.jpg
var footer_logo = __webpack_require__(948);
// EXTERNAL MODULE: ./src/data/contactData.js
var contactData = __webpack_require__(2224);
;// CONCATENATED MODULE: ./src/data/footerData.js



const footerData = {
    ...contactData/* contact */.P,
    link: "Halpes",
    copyrightYear: new Date().getFullYear(),
    about: "Lorem ipsum dolor sit ame consect etur pisicing elit sed do eiusmod tempor incididunt ut labore.",
    bottomLogo: footer_logo["default"].src,
    footerBg: footer_bg["default"].src,
    social: [
        {
            id: 1,
            href: "#",
            icon: "fa-twitter"
        },
        {
            id: 2,
            href: "#",
            icon: "fa-facebook-square"
        },
        {
            id: 3,
            href: "#",
            icon: "fa-dribbble"
        },
        {
            id: 4,
            href: "#",
            icon: "fa-instagram"
        }
    ],
    exploreList: [
        {
            id: 1,
            href: "#",
            title: "Donate"
        },
        {
            id: 2,
            href: "#",
            title: "Campaigns"
        },
        {
            id: 3,
            href: "#",
            title: "Fundraise"
        },
        {
            id: 4,
            href: "#",
            title: "Volunteers"
        },
        {
            id: 5,
            href: "#",
            title: "Sponsors"
        },
        {
            id: 6,
            href: "#",
            title: "Fundraising"
        },
        {
            id: 7,
            href: "#",
            title: "Contact"
        },
        {
            id: 8,
            href: "#",
            title: "Help"
        },
        {
            id: 9,
            href: "#",
            title: "Faqs"
        }
    ]
};
/* harmony default export */ const data_footerData = (footerData);

;// CONCATENATED MODULE: ./src/components/SiteFooter/SiteFooter.js





const { exploreList , social , email , tel , officeAddress , about , link: SiteFooter_link , copyrightYear , bottomLogo , footerBg ,  } = data_footerData;
const SiteFooter = ()=>{
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)("footer", {
        className: "site-footer",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: "site-footer-bg",
                style: {
                    backgroundImage: `url(${footerBg})`
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Container, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "site-footer__top",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(external_react_bootstrap_.Row, {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                    xl: 3,
                                    lg: 6,
                                    md: 6,
                                    className: "fadeInUp",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "footer-widget__column footer-widget__about",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                className: "footer-widget__title",
                                                children: "About"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "footer-widget__text",
                                                children: about
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("a", {
                                                href: "#",
                                                className: "footer-widget__about-btn",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                        className: "fa fa-heart"
                                                    }),
                                                    "Donate"
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                    xl: 3,
                                    lg: 6,
                                    md: 6,
                                    className: "wow fadeInUp",
                                    "data-wow-delay": "200ms",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "footer-widget__column footer-widget__explore clearfix",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                className: "footer-widget__title",
                                                children: "Explore"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                className: "footer-widget__explore-list list-unstyled",
                                                children: exploreList.slice(0, 5).map(({ id , title , href  })=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            href: href,
                                                            children: title
                                                        })
                                                    }, id)
                                                )
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("ul", {
                                                className: "footer-widget__explore-list footer-widget__explore-list-two list-unstyled",
                                                children: exploreList.slice(5).map(({ id , title , href  })=>/*#__PURE__*/ jsx_runtime_.jsx("li", {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            href: href,
                                                            children: title
                                                        })
                                                    }, id)
                                                )
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                    xl: 3,
                                    lg: 6,
                                    md: 6,
                                    className: "fadeInUp",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "footer-widget__column footer-widget__contact",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                className: "footer-widget__title",
                                                children: "Contact"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                                className: "list-unstyled footer-widget__contact-list",
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "icon",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "icon-chat"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "text",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            children: "Call Anytime"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                            href: `tel:${tel}`,
                                                                            children: tel
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "icon",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "icon-message"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "text",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            children: "Send Email"
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                                            href: `mailto:${email}`,
                                                                            children: email
                                                                        })
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "icon",
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                    className: "icon-address"
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                                className: "text",
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                                            children: "Visit Office"
                                                                        }),
                                                                        officeAddress
                                                                    ]
                                                                })
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                    xl: 3,
                                    lg: 6,
                                    md: 6,
                                    className: "wow fadeInUp",
                                    "data-wow-delay": "400ms",
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        className: "footer-widget__column footer-widget__newsletter",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                                className: "footer-widget__title",
                                                children: "Newsletter"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                className: "footer-widget__newsletter-text",
                                                children: "Lorem ipsum dolor sit ame consect etur pisicing elit sed do."
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                                className: "footer-widget__newsletter-form",
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                                        type: "email",
                                                        placeholder: "Email address",
                                                        name: "email"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("button", {
                                                        type: "submit",
                                                        className: "footer-widget__newsletter-btn",
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: "fas fa-arrow-circle-right"
                                                            }),
                                                            "Send"
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        className: "site-footer__bottom",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Row, {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Col, {
                                xl: 12,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    className: "site-footer__bottom-inner",
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            className: "site-footer__bottom-logo-social",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "site-footer__bottom-logo",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(next_link["default"], {
                                                        href: "/",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(external_react_bootstrap_.Image, {
                                                                src: bottomLogo,
                                                                alt: ""
                                                            })
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    className: "site-footer__bottom-social",
                                                    children: social.map(({ id , icon , href  })=>/*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                            href: href,
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                                                                className: `fab ${icon}`
                                                            })
                                                        }, id)
                                                    )
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            className: "site-footer__bottom-copy-right",
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                                children: [
                                                    "\xa9 Copyright ",
                                                    copyrightYear,
                                                    " by",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("a", {
                                                        target: "_blank",
                                                        rel: "noreferrer",
                                                        href: `https://${SiteFooter_link}`,
                                                        children: SiteFooter_link
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            })
                        })
                    })
                ]
            })
        ]
    }));
};
/* harmony default export */ const SiteFooter_SiteFooter = (SiteFooter);

;// CONCATENATED MODULE: ./src/components/Layout/Layout.js











const Layout = ({ children , pageTitle  })=>{
    const { 0: loading , 1: setLoading  } = (0,external_react_.useState)(true);
    const { menuStatus  } = (0,context/* useRootContext */.E)();
    const { scrollTop  } = (0,useScroll/* default */.Z)(70);
    (0,external_react_.useEffect)(()=>{
        setTimeout(()=>{
            setLoading(false);
        }, 500);
    }, []);
    return(/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "width=device-width, initial-scale=1.0"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("title", {
                        children: [
                            pageTitle,
                            " || Halpes || NextJS Template For Donation Services"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components_Preloader, {
                loading: loading
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                id: "wrapper",
                style: {
                    opacity: loading ? 0 : 1
                },
                className: "page-wrapper",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Header_Header, {
                        pageTitle: pageTitle
                    }),
                    children,
                    /*#__PURE__*/ jsx_runtime_.jsx(SiteFooter_SiteFooter, {})
                ]
            }),
            menuStatus && /*#__PURE__*/ jsx_runtime_.jsx(MobileMenu_MobileMenu, {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Search_Search, {}),
            scrollTop && /*#__PURE__*/ jsx_runtime_.jsx(external_react_scroll_.Link, {
                to: "wrapper",
                smooth: true,
                duration: 500,
                id: "backToTop",
                style: {
                    cursor: "pointer"
                },
                className: "scroll-to-target scroll-to-top fadeIn animated",
                children: /*#__PURE__*/ jsx_runtime_.jsx("i", {
                    className: "fa fa-angle-up"
                })
            })
        ]
    }));
};
/* harmony default export */ const Layout_Layout = (Layout);


/***/ }),

/***/ 9343:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ useRootContext),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const context = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({});
const useRootContext = ()=>{
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(context);
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (context);


/***/ }),

/***/ 4181:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "x": () => (/* binding */ social)
/* harmony export */ });
const navItems = [
    {
        id: 1,
        name: "Home",
        href: "/",
        subNavItems: [
            {
                id: 1,
                name: "Home One",
                href: "/"
            },
            {
                id: 2,
                name: "Home Two",
                href: "/home2"
            },
            {
                id: 3,
                name: "Home Three",
                href: "/home3"
            },
            {
                id: 4,
                name: "Header Styles",
                href: "/",
                subItems: [
                    {
                        id: 1,
                        name: "Header One",
                        href: ""
                    },
                    {
                        id: 2,
                        name: "Header Two",
                        href: ""
                    },
                    {
                        id: 3,
                        name: "Header Three",
                        href: ""
                    }, 
                ]
            }, 
        ]
    },
    {
        id: 2,
        name: "Pages",
        href: "",
        subNavItems: [
            {
                id: 1,
                name: "About",
                href: "/about"
            },
            {
                id: 2,
                name: "Volunteers",
                href: "/volunteers"
            },
            {
                id: 3,
                name: "Gallery",
                href: "/gallery"
            },
            {
                id: 4,
                name: "Become a Volunteer",
                href: "/become-volunteer"
            }, 
        ]
    },
    {
        id: 3,
        name: "Donations",
        href: "/causes",
        subNavItems: [
            {
                id: 1,
                name: "Causes",
                href: "/causes"
            },
            {
                id: 2,
                name: "Causes Details",
                href: "/causes-details"
            }, 
        ]
    },
    {
        id: 4,
        name: "Events",
        href: "/events",
        subNavItems: [
            {
                id: 1,
                name: "Events",
                href: "/events"
            },
            {
                id: 2,
                name: "Event Details",
                href: "/event-details"
            }, 
        ]
    },
    {
        id: 5,
        name: "News",
        href: "/news",
        subNavItems: [
            {
                id: 1,
                name: "News",
                href: "/news"
            },
            {
                id: 2,
                name: "News Details",
                href: "/news-details"
            }, 
        ]
    },
    {
        id: 6,
        name: "Contact",
        href: "/contact",
        subNavItems: []
    }, 
];
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (navItems);
const social = [
    {
        icon: "fa-twitter",
        link: ""
    },
    {
        icon: "fa-facebook-square",
        link: ""
    },
    {
        icon: "fa-dribbble",
        link: ""
    },
    {
        icon: "fa-instagram",
        link: ""
    }, 
];


/***/ }),

/***/ 2224:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ contact),
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _images_resources_contact_page_img_1_jpg__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(575);

const contact = {
    tel: "92 666 888 0000",
    email: "needhelp@company.com",
    officeAddress: "80 broklyn golden street"
};
const contactData = {
    ...contact,
    image: _images_resources_contact_page_img_1_jpg__WEBPACK_IMPORTED_MODULE_0__["default"],
    description: "There are many variations of passages of available but the majority have suffered alteration in some form, by injected humou or randomised words even slightly believable."
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (contactData);


/***/ }),

/***/ 292:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const useScroll = (scrollSize = 0)=>{
    const { 0: scroll , 1: setScroll  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(0);
    const { 0: scrollTop , 1: setScrollTop  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const handleSet = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        setScroll(window === null || window === void 0 ? void 0 : window.scrollY);
        if ((window === null || window === void 0 ? void 0 : window.scrollY) > scrollSize) {
            setScrollTop(true);
        } else {
            setScrollTop(false);
        }
    }, [
        scrollSize
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        handleSet();
        window.addEventListener("scroll", handleSet);
        return ()=>window.removeEventListener("scroll", handleSet)
        ;
    }, [
        handleSet
    ]);
    return {
        scroll,
        scrollTop
    };
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (useScroll);


/***/ })

};
;